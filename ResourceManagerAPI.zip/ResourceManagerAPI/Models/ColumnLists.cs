﻿namespace ResourceManagerAPI.Models
{
    public class ColumnLists
    {
     public int Id { get; set; }   
     public string? ColumnList { get; set; }
    }
}

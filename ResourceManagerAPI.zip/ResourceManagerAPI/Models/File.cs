﻿namespace ResourceManagerAPI.Models
{
    public class File
    {
        public IFormFile PlanFile { get; set; }
    }
}

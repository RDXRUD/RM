﻿namespace ResourceManagerAPI.Models
{
    public class SkillResourceModel
    {
        public int resourceid { get; set; }
        public int skillid { get; set; }
    }
}

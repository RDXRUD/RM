﻿namespace ResourceManagerAPI.Models
{
    public class ResourceName
    {
        public int? ResourceID { get; set; }
        public int? EmpID { get; set; }
        public string? Email { get; set; }
    }
}

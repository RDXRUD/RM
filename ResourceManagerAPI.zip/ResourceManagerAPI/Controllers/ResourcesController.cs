﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ResourceManagerAPI.DBContext;
using ResourceManagerAPI.IRepository;
using ResourceManagerAPI.Models;
using System.Diagnostics;
using Resources = ResourceManagerAPI.Models.Resources;

namespace ResourceManagerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResourcesController : ControllerBase
    {
        private readonly IAccount _account;
        private readonly PGDBContext _dbContext;
        public ResourcesController(IAccount account,  PGDBContext context)
        {
            _account = account;
            _dbContext = context;
        }

        [HttpGet, Authorize]
        [Route("GetResources")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var resources = (from rm in _dbContext.resource_master.Where(s=>s.status=="ACTIVE")
                                 join lm in _dbContext.location_master
                                 on rm.location_id equals lm.id into detail
                                 from m in detail.DefaultIfEmpty()
                                 select new ResourceLocation
                                 {
                                     res_id = rm.res_id,
                                     res_name = rm.res_name,
                                     res_email_id = rm.res_email_id,
                                     res_user_id = rm.res_user_id,
                                     res_create_date = rm.res_create_date,
                                     res_last_modified = rm.res_last_modified,
                                     sso_flag = rm.sso_flag,
                                     location = m.location,
                                 }
                                ).ToList();//await _dbContext.resource_master.ToListAsync();
                return Ok(resources); // Return a 200 OK response with the data
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); // Return a 500 Internal Server Error with the error message
            }
        }

        [HttpGet, Authorize]
        [Route("GetResource/{id}")]
        public async Task<IActionResult> GetResource(int id)
        {
            try
            {
                var resources = (from rm in _dbContext.resource_master.Where(s => s.res_id == id)
                                 join lm in _dbContext.location_master
                                 on rm.location_id equals lm.id into detail
                                 from m in detail.DefaultIfEmpty()
                                 //orderby rm.res_id
                                 select new ResourceLocation
                                 {
                                     res_id = rm.res_id,
                                     res_name = rm.res_name,
                                     res_email_id = rm.res_email_id,
                                     res_user_id = rm.res_user_id,
                                     res_create_date = rm.res_create_date,
                                     res_last_modified = rm.res_last_modified,
                                     sso_flag = rm.sso_flag,
                                     location = m.location,
                                 }
                                ).ToList();//await _dbContext.resource_master.ToListAsync();
                resources = resources.OrderBy(r => r.res_id).ToList();
                return Ok(resources); // Return a 200 OK response with the data
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); // Return a 500 Internal Server Error with the error message
            }
        }


        [HttpPost, Authorize]
        [Route("AddResource")]
        public async Task<IActionResult> AddResource([FromBody] ResourceLocation resLoc)
        {
            try
            {
                if (resLoc == null)
                {
                    return BadRequest("Employee data is null.");
                }
                Resources res = new Resources();
                ResourceMaster resource = new ResourceMaster();
                Login user = new Login();   
                var testEmail = await _dbContext.resource_master.Where(e => e.res_email_id == resLoc.res_email_id).FirstOrDefaultAsync();
                if (testEmail != null)
                {
                    return StatusCode(501, "Email already exist");
                }
                var testUserID = await _dbContext.resource_master.Where(id => id.res_user_id == resLoc.res_user_id).FirstOrDefaultAsync();
                if (testUserID != null)
                {
                    return StatusCode(502, "UserID already exist");
                }
                res.ResourceID = await _dbContext.resources.MaxAsync(r => r.ResourceID) + 1;
                resLoc.res_id = await _dbContext.resource_master.MaxAsync(r => r.res_id) + 1;
                res.EmailID = resLoc.res_email_id;
                resource.res_name = resLoc.res_name;
                resource.res_user_id = resLoc.res_user_id;
                resource.res_email_id = resLoc.res_email_id;
                resource.sso_flag = resLoc.sso_flag;
                resource.res_last_modified= DateTime.UtcNow.Date;
                var temp = _dbContext.location_master.FirstOrDefault(l => l.location == resLoc.location);
                resource.location_id=temp.id;
                user.UserID = resLoc.res_user_id;
                user.Password = resLoc.password;
                resource.password = _account.ResourcePass(user);
                _dbContext.resources.Add(res);
                _dbContext.resource_master.Add(resource);
                await _dbContext.SaveChangesAsync();

                return CreatedAtAction("AddResource", new { id = resource.res_id }, resource);
            }
            catch (DbUpdateException ex)
            {
                // Handle the exception as needed
                return StatusCode(500, "An error occurred while saving the entity changes.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut, Authorize]
        [Route("EditResource/{id}")]
        public async Task<IActionResult> EditResource(int id, [FromBody] ResourceLocation updatedResource)
        {
            Resources resource = new Resources();
            try
            {
                if (updatedResource == null)
                {
                    return BadRequest("Employee data is null.");
                }

                var existingResource = await _dbContext.resource_master.FindAsync(id);

                if (existingResource == null)
                {
                    return NotFound($"Employee with ID {id} not found.");
                }
                var testEmail = await _dbContext.resource_master.Where(e => e.res_email_id == updatedResource.res_email_id).FirstOrDefaultAsync();
                if (testEmail != null)
                {
                    return StatusCode(501, "Email already exist");
                }
                var testUserID = await _dbContext.resource_master.Where(id => id.res_user_id == updatedResource.res_user_id).FirstOrDefaultAsync();
                if (testUserID != null)
                {
                    return StatusCode(502, "UserID already exist");
                }

                if (existingResource.res_email_id != updatedResource.res_email_id)
                {
                    // Email ID is being updated, so update the corresponding Resource
                    var res = await _dbContext.resources
                        .FirstOrDefaultAsync(r => r.EmailID == existingResource.res_email_id);

                    if (res != null)
                    {
                        resource.EmailID = updatedResource.res_email_id;
                        existingResource.res_email_id = updatedResource.res_email_id;
                    }
                }

                // Update employee details
                existingResource.res_name = updatedResource.res_name;
                var temp = _dbContext.location_master.FirstOrDefault(l => l.location == updatedResource.location);
                existingResource.location_id = temp.id;
                existingResource.sso_flag= updatedResource.sso_flag;
                existingResource.res_last_modified = DateTime.UtcNow.Date;

                // Save changes
                await _dbContext.SaveChangesAsync();

                return Ok(existingResource);
            }

            catch (DbUpdateException ex)
            {
                // Handle the exception as needed
                return StatusCode(500, "An error occurred while updating employee details.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut, Authorize]
        [Route("EditStatus/{id}")]
        public async Task<IActionResult> EditStatus(int id)
        {
            try
            {
                
                var existingResource = await _dbContext.resource_master.FindAsync(id);

                if (existingResource == null)
                {
                    return NotFound($"Resource with ID {id} not found.");
                }

                // Update employee details
                existingResource.status = "INACTIVE";
                existingResource.res_last_modified = DateTime.UtcNow.Date;

                // Save changes
                await _dbContext.SaveChangesAsync();

                return Ok(existingResource);
            }

            catch (DbUpdateException ex)
            {
                // Handle the exception as needed
                return StatusCode(500, "An error occurred while updating employee details.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut, Authorize]
        [Route("ResetPassword/{id}")]
        public async Task<IActionResult> ResetPassword(int id, [FromBody] ResourceMaster updatedResource)
        {
            try
            {
                Login user = new Login();
                var userName = User.Identity.Name;
                var existingResource = await _dbContext.resource_master.FindAsync(id);

                if (existingResource == null)
                {
                    return NotFound($"Resource with ID {id} not found.");
                }

                // Update employee details
                user.UserID = existingResource.res_user_id;
                //if (user.UserID != userName)
                //{

                //}
                Debug.WriteLine(userName);
                user.Password = updatedResource.password;
                existingResource.password = _account.ResourcePass(user);
                existingResource.res_last_modified = DateTime.UtcNow.Date;
                
                // Save changes
                await _dbContext.SaveChangesAsync();

                return Ok(existingResource);
            }

            catch (DbUpdateException ex)
            {
                // Handle the exception as needed
                return StatusCode(500, "An error occurred while updating employee details.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpDelete, Authorize]
        [Route("DeleteEmployee/{id}")]
        [NonAction]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employeeToDelete = await _dbContext.employees.FindAsync(id);

                if (employeeToDelete == null)
                {
                    return NotFound($"Employee with ID {id} not found.");
                }

                _dbContext.employees.Remove(employeeToDelete);
                await _dbContext.SaveChangesAsync();

                return NoContent();
            }
            catch (DbUpdateException ex)
            {
                // Handle the exception as needed
                return StatusCode(500, "An error occurred while deleting the employee.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


    }
}
